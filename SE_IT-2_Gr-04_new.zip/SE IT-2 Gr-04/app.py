"""
AutoCare Garage — Online Vehicle Servicing Management System
--------------------------------------------------------------
Flask web application entry point.

Run with:   python app.py
Then open:  http://127.0.0.1:5000  in your browser.

Default staff/admin login: admin@autocare.com / AutoCare1234
(This can be changed from the Profile page once logged in as staff.)
"""
import csv
import io
from datetime import date
from functools import wraps

from flask import Flask, Response, flash, redirect, render_template, request, session, url_for

from vehicle_service import analytics, database
from vehicle_service.exceptions import (
    VehicleAlreadyBookedError,
    SlotPassedError,
    BookingNotFoundError,
    InvalidCredentialsError,
    MechanicNotAssignedError,
    MechanicNotFoundError,
    MechanicUnavailableError,
    NoBayAvailableError,
    SparePartNotFoundError,
    UserAlreadyExistsError,
    VehicleNotFoundError,
)
from vehicle_service.models import (
    GarageSettings,
    Mechanic,
    ServiceBooking,
    ServicePricing,
    SparePart,
    TIME_SLOTS,
    User,
    Vehicle,
)
from vehicle_service.notifications import send_booking_confirmation

app = Flask(__name__)
app.secret_key = "college-mini-project-dev-secret-key"  # fine for local/college demo use

# The project only services cars, so this is intentionally a single fixed
# option rather than a dropdown of vehicle types.
VEHICLE_TYPES = ["Car"]

SERVICE_TYPES = ["General Service", "Oil Change", "Other"]

# Simulated third-party spare-parts vendors an admin can restock from when a
# part is low/out of stock. price_multiplier is applied on top of the part's
# catalog price to simulate each vendor's own pricing.
VENDORS = [
    {"name": "AutoParts Hub", "price_multiplier": 1.00},
    {"name": "SpeedyParts Wholesale", "price_multiplier": 0.90},
    {"name": "CityGarage Supplies", "price_multiplier": 1.15},
]


# --------------------------------------------------------------------- helpers --
def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if current_user() is None:  # not logged in, or account no longer exists
            flash("Please log in to continue.", "error")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if current_user() is None:
            flash("Please log in to continue.", "error")
            return redirect(url_for("login"))
        if not session.get("is_admin"):
            flash("That page is for service-center staff only.", "error")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped


def current_user():
    """The logged-in User, or None. If the session points at an account that
    no longer exists (e.g. the database was recreated), the stale session is
    cleared so the person is simply asked to log in again."""
    if "user_id" in session:
        user = User.get_by_id(session["user_id"])
        if user is None:
            session.clear()
        return user
    return None


@app.context_processor
def inject_user():
    return {"logged_in_user": current_user()}


@app.context_processor
def inject_garage_contact():
    """Garage customer-care phone/email, available on every page."""
    return {"garage_contact": GarageSettings.get_contact()}


@app.context_processor
def inject_low_stock_alerts():
    """Out-of-stock / low-stock warnings are surfaced only to staff — a
    customer has no restocking action to take, so they never see this."""
    if session.get("is_admin"):
        return {"low_stock_alerts": SparePart.low_stock_parts()}
    return {"low_stock_alerts": []}


# --------------------------------------------------------------------------- auth --
@app.route("/")
def index():
    if current_user() is not None:
        return redirect(url_for("admin_dashboard") if session.get("is_admin") else url_for("dashboard"))
    return render_template("index.html", service_prices=ServicePricing.all(), pickup_fee=GarageSettings.get_pickup_fee())


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not full_name or not email or not password:
            flash("Name, email and password are required.", "error")
        elif not (phone.isascii() and phone.isdigit() and len(phone) == 10):
            flash("Phone number is required and must be exactly 10 digits.", "error")
        elif password != confirm:
            flash("Passwords do not match.", "error")
        elif len(password) < 6:
            flash("Password must be at least 6 characters long.", "error")
        else:
            try:
                User.register(full_name, email, phone, password)
                flash("Account created successfully. Please log in.", "success")
                return redirect(url_for("login"))
            except UserAlreadyExistsError as e:
                flash(str(e), "error")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        try:
            user = User.authenticate(email, password)
            session["user_id"] = user.id
            session["is_admin"] = user.is_admin
            flash(f"Welcome back, {user.full_name}!", "success")
            return redirect(url_for("admin_dashboard") if user.is_admin else url_for("dashboard"))
        except InvalidCredentialsError as e:
            flash(str(e), "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))


# ----------------------------------------------------------------- customer views --
@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    vehicles = Vehicle.find_by_user(user.id)
    bookings = ServiceBooking.find_by_user(user.id)
    upcoming_count = len([
        b for b in bookings
        if b.status in ("Confirmed", "In Progress") and b.preferred_date >= str(date.today())
    ])
    issue_bookings = [b for b in bookings if b.mechanic_issue and b.status == "Confirmed"]
    return render_template("dashboard.html", user=user, vehicles=vehicles,
                            bookings=bookings, upcoming_count=upcoming_count,
                            issue_bookings=issue_bookings)


@app.route("/bookings/<int:booking_id>/mechanic/reassign", methods=["POST"])
@login_required
def reassign_mechanic(booking_id):
    """Popup option 1: let the garage assign a different available mechanic."""
    try:
        name = ServiceBooking.reassign_mechanic(booking_id, session["user_id"])
        flash(f"Done! {name} has been assigned to your booking.", "success")
    except (BookingNotFoundError, MechanicUnavailableError) as e:
        flash(str(e), "error")
    return redirect(url_for("dashboard"))


@app.route("/bookings/<int:booking_id>/reschedule", methods=["GET", "POST"])
@login_required
def reschedule_booking(booking_id):
    """Popup option 2: rearrange the service to another date / time slot."""
    try:
        booking = ServiceBooking.get(booking_id)
    except BookingNotFoundError as e:
        flash(str(e), "error")
        return redirect(url_for("my_bookings"))
    if booking.user_id != session["user_id"] or booking.status != "Confirmed":
        flash("Only your own confirmed bookings can be rearranged.", "error")
        return redirect(url_for("my_bookings"))

    selected_date = request.values.get("preferred_date") or booking.preferred_date
    if selected_date < str(date.today()):
        selected_date = str(date.today())
    if request.method == "POST" and request.form.get("time_slot"):
        pick = request.form.get("mechanic_pick", "any")
        try:
            ServiceBooking.reschedule(booking_id, session["user_id"], selected_date,
                                      request.form.get("time_slot"),
                                      int(pick) if pick.isdigit() else None)
            flash("Your service has been rearranged.", "success")
            return redirect(url_for("my_bookings"))
        except (VehicleAlreadyBookedError, NoBayAvailableError, SlotPassedError,
                MechanicUnavailableError, MechanicNotFoundError, ValueError) as e:
            flash(str(e), "error")
    return render_template("reschedule.html", booking=booking, selected_date=selected_date,
                            today=str(date.today()), time_slots=TIME_SLOTS,
                            availability=ServiceBooking.slot_availability(selected_date),
                            passed=ServiceBooking.passed_slots(selected_date),
                            mechanics=Mechanic.all(active_only=True),
                            busy_slots=ServiceBooking.busy_mechanic_slots(selected_date))


@app.route("/vehicles")
@login_required
def my_vehicles():
    vehicles = Vehicle.find_by_user(session["user_id"])
    return render_template("my_vehicles.html", vehicles=vehicles)


@app.route("/vehicles/add", methods=["GET", "POST"])
@login_required
def add_vehicle():
    if request.method == "POST":
        # Vehicle type is fixed to "Car" — the form only sends brand/model/etc.
        brand = request.form.get("brand", "").strip()
        model = request.form.get("model", "").strip()
        reg_no = request.form.get("registration_number", "").strip().upper()
        year = request.form.get("year") or None

        if not (brand and model and reg_no):
            flash("Please fill in all required fields.", "error")
        else:
            Vehicle.create(session["user_id"], "Car", brand, model, reg_no, year)
            flash("Vehicle added successfully.", "success")
            return redirect(url_for("my_vehicles"))
    return render_template("add_vehicle.html")


@app.route("/vehicles/<int:vehicle_id>/delete", methods=["POST"])
@login_required
def delete_vehicle(vehicle_id):
    try:
        Vehicle.delete(vehicle_id, session["user_id"])
        flash("Vehicle removed.", "success")
    except VehicleNotFoundError as e:
        flash(str(e), "error")
    return redirect(url_for("my_vehicles"))


@app.route("/book-service", methods=["GET", "POST"])
@login_required
def book_service():
    vehicles = Vehicle.find_by_user(session["user_id"])
    selected_date = request.values.get("preferred_date") or str(date.today())
    if selected_date < str(date.today()):
        selected_date = str(date.today())
    availability = ServiceBooking.slot_availability(selected_date)
    passed = ServiceBooking.passed_slots(selected_date)
    popup_message = None
    service_prices = ServicePricing.all()
    # Every service lists its parts so the customer can tick only the ones
    # they want replaced (they pay only for the parts they select).
    parts_by_service = {service: SparePart.by_category(service) for service in SERVICE_TYPES}

    if request.method == "POST":
        vehicle_id = request.form.get("vehicle_id", type=int)
        service_type = request.form.get("service_type")
        time_slot = request.form.get("time_slot")
        notes = request.form.get("notes", "").strip()
        pickup_required = request.form.get("pickup_required") == "on"
        pickup_address = request.form.get("pickup_address", "").strip()
        part_ids = request.form.getlist("part_ids", type=int)
        # "any" = garage assigns a mechanic; "specific" = customer picks one.
        pick = request.form.get("mechanic_pick", "any")
        mechanic_id = int(pick) if pick.isdigit() else None

        if not (vehicle_id and service_type and selected_date and time_slot):
            flash("Please complete every field.", "error")
        elif pickup_required and not pickup_address:
            flash("Please enter a pickup address, or untick Pickup Required.", "error")
        else:
            try:
                Vehicle.get_owned(vehicle_id, session["user_id"])
                booking_id, bay = ServiceBooking.create(
                    session["user_id"], vehicle_id, service_type, selected_date, time_slot, notes,
                    pickup_required=pickup_required, pickup_address=pickup_address,
                    part_ids=part_ids, mechanic_id=mechanic_id,
                )
                user = current_user()
                send_booking_confirmation(user.email, booking_id, selected_date, time_slot, bay)
                if ServiceBooking.get(booking_id).mechanic_issue:
                    flash("Booking confirmed, but the mechanic you chose isn't available at that time. "
                          "Please choose what to do next.", "error")
                    return redirect(url_for("dashboard"))
                flash(f"Booking confirmed! Bay {bay} reserved for {selected_date}, {time_slot}.", "success")
                return redirect(url_for("my_bookings"))
            except VehicleAlreadyBookedError as e:
                popup_message = str(e)  # shown as a pop-up on the booking page
            except (VehicleNotFoundError, NoBayAvailableError, SlotPassedError,
                    MechanicUnavailableError, MechanicNotFoundError) as e:
                flash(str(e), "error")
                availability = ServiceBooking.slot_availability(selected_date)
                passed = ServiceBooking.passed_slots(selected_date)

    return render_template(
        "book_service.html", passed=passed, mechanics=Mechanic.all(active_only=True),
        busy_slots=ServiceBooking.busy_mechanic_slots(selected_date), popup_message=popup_message, today=str(date.today()), vehicles=vehicles, service_types=SERVICE_TYPES,
        time_slots=TIME_SLOTS, availability=availability, selected_date=selected_date,
        service_prices=service_prices, parts_by_service=parts_by_service, pickup_fee=GarageSettings.get_pickup_fee(),
    )


@app.route("/my-bookings")
@login_required
def my_bookings():
    bookings = ServiceBooking.find_by_user(session["user_id"])
    return render_template("my_bookings.html", bookings=bookings)


@app.route("/bookings/<int:booking_id>/cancel", methods=["POST"])
@login_required
def cancel_booking(booking_id):
    try:
        ServiceBooking.cancel(booking_id, session["user_id"])
        flash("Booking cancelled.", "success")
    except BookingNotFoundError as e:
        flash(str(e), "error")
    return redirect(url_for("my_bookings"))


@app.route("/bookings/<int:booking_id>/delivery", methods=["GET", "POST"])
@login_required
def choose_delivery(booking_id):
    """After the service is complete: deliver to my address (yes) or I'll
    collect it myself at a chosen time (no). Also used to re-book a missed
    collection."""
    try:
        booking = ServiceBooking.get(booking_id)
    except BookingNotFoundError as e:
        flash(str(e), "error")
        return redirect(url_for("my_bookings"))
    if booking.user_id != session["user_id"]:
        flash("You can only manage your own bookings.", "error")
        return redirect(url_for("my_bookings"))
    if booking.status != "Completed":
        flash("Delivery options appear once your service is completed.", "error")
        return redirect(url_for("my_bookings"))
    if booking.delivery_status in ("Delivered", "Collected"):
        flash("This vehicle has already been handed over.", "success")
        return redirect(url_for("my_bookings"))

    if request.method == "POST":
        home_delivery = request.form.get("home_delivery") == "yes"
        try:
            ServiceBooking.set_delivery(
                booking_id, session["user_id"], home_delivery,
                delivery_address=request.form.get("delivery_address", "").strip(),
                collect_date=request.form.get("collect_date", ""),
                collect_slot=request.form.get("collect_slot", ""),
            )
            flash("We'll deliver your vehicle to your address." if home_delivery
                  else "Pickup time saved. Please collect your vehicle in the chosen slot.", "success")
            return redirect(url_for("my_bookings"))
        except (ValueError, BookingNotFoundError) as e:
            flash(str(e), "error")

    return render_template("delivery_choice.html", booking=booking, time_slots=TIME_SLOTS,
                            today=str(date.today()))


@app.route("/spare-parts")
@login_required
def spare_parts():
    """Read-only spare-parts catalog so customers can see part availability
    and pricing before booking — matches the project's parts-availability
    objective."""
    parts_by_category = {service: SparePart.by_category(service) for service in SERVICE_TYPES}
    return render_template("spare_parts.html", parts_by_category=parts_by_category)


@app.route("/profile", methods=["GET", "POST"])
@login_required
def customer_profile():
    user = current_user()
    if request.method == "POST":
        current_password = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not new_password:
            flash("Enter a new password to update it.", "error")
        elif new_password != confirm_password:
            flash("New passwords do not match.", "error")
        elif len(new_password) < 6:
            flash("New password must be at least 6 characters long.", "error")
        else:
            try:
                User.update_credentials(user.id, current_password, new_password=new_password)
                flash("Your password has been updated.", "success")
                return redirect(url_for("customer_profile"))
            except InvalidCredentialsError as e:
                flash(str(e), "error")
    return render_template("profile.html", user=user)


@app.route("/account/delete", methods=["POST"])
@login_required
def delete_account():
    """Permanently deletes the account and (via cascading foreign keys) every
    vehicle and booking tied to it — matches the requirement that data is
    kept 'permanently until he or she deletes the account'."""
    password = request.form.get("password", "")
    user = current_user()
    try:
        User.authenticate(user.email, password)  # confirm identity first
        user.delete()
        session.clear()
        flash("Your account and all related data have been permanently deleted.", "success")
        return redirect(url_for("index"))
    except InvalidCredentialsError:
        flash("Incorrect password — your account was NOT deleted.", "error")
        return redirect(url_for("customer_profile"))


@app.route("/bookings/<int:booking_id>/invoice")
@login_required
def view_invoice(booking_id):
    """Itemized invoice/receipt for a completed booking. Customers can only
    view their own; staff can view any."""
    try:
        booking = ServiceBooking.get(booking_id)
    except BookingNotFoundError as e:
        flash(str(e), "error")
        return redirect(url_for("my_bookings"))

    if not session.get("is_admin") and booking.user_id != session["user_id"]:
        flash("You can only view your own invoices.", "error")
        return redirect(url_for("my_bookings"))

    if booking.status != "Completed":
        flash("The invoice becomes available once the service is marked Completed.", "error")
        return redirect(url_for("admin_dashboard") if session.get("is_admin") else url_for("my_bookings"))

    parts_used = ServiceBooking.get_parts_used(booking_id)
    return render_template("invoice.html", booking=booking, parts_used=parts_used)


# ---------------------------------------------------------------------------- admin --
@app.route("/admin")
@admin_required
def admin_dashboard():
    bookings = ServiceBooking.find_all()
    status_filter = request.args.get("status", "All")
    if status_filter != "All":
        bookings = [b for b in bookings if b.status == status_filter]
    statuses = ["Confirmed", "In Progress", "Completed", "Cancelled"]
    return render_template("admin_dashboard.html", bookings=bookings, statuses=statuses,
                            status_filter=status_filter, mechanics=Mechanic.all(active_only=True))


@app.route("/admin/bookings/<int:booking_id>/status", methods=["POST"])
@admin_required
def update_booking_status(booking_id):
    new_status = request.form.get("status")
    try:
        booking = ServiceBooking.get(booking_id)
        if new_status == "Completed" and booking.service_type == "Other":
            flash("For 'Other' service bookings, use 'Complete & Select Parts' to finish the job.", "error")
            return redirect(url_for("admin_dashboard"))
        ServiceBooking.update_status(booking_id, new_status)
        flash(f"Booking #{booking_id} marked as {new_status}.", "success")
    except (BookingNotFoundError, MechanicNotAssignedError) as e:
        flash(str(e), "error")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/bookings/<int:booking_id>/handover", methods=["POST"])
@admin_required
def mark_handed_over(booking_id):
    try:
        result = ServiceBooking.mark_handed_over(booking_id, request.form.get("outcome", ""))
        flash(f"Booking #{booking_id}: marked as {result}.", "success")
    except (BookingNotFoundError, ValueError) as e:
        flash(str(e), "error")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/bookings/<int:booking_id>/assign", methods=["POST"])
@admin_required
def assign_mechanic(booking_id):
    """Admin picks the mechanic who will work on this booking. Customers see
    the assigned mechanic on their Dashboard / My Bookings / invoice."""
    mechanic_id = request.form.get("mechanic_id", type=int)
    if not mechanic_id:
        flash("Choose a mechanic to assign.", "error")
        return redirect(url_for("admin_dashboard"))
    try:
        name = ServiceBooking.assign_mechanic(booking_id, mechanic_id)
        flash(f"{name} assigned to booking #{booking_id}.", "success")
    except (BookingNotFoundError, MechanicNotFoundError, MechanicUnavailableError) as e:
        flash(str(e), "error")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/bookings/<int:booking_id>/complete-other", methods=["GET", "POST"])
@admin_required
def complete_other_booking(booking_id):
    """For a booking whose service_type is 'Other', staff pick which spare
    parts were actually used before it can be marked Completed. This is what
    generates the invoice amount and itemized invoice bill for that job."""
    try:
        booking = ServiceBooking.get(booking_id)
    except BookingNotFoundError as e:
        flash(str(e), "error")
        return redirect(url_for("admin_dashboard"))

    if booking.service_type != "Other":
        flash("This flow only applies to 'Other' service bookings.", "error")
        return redirect(url_for("admin_dashboard"))

    if request.method == "POST":
        part_ids = request.form.getlist("part_ids", type=int)
        try:
            ServiceBooking.complete_with_parts(booking_id, part_ids)
        except MechanicNotAssignedError as e:
            flash(str(e), "error")
            return redirect(url_for("admin_dashboard"))
        flash(f"Booking #{booking_id} completed — invoice generated.", "success")
        return redirect(url_for("admin_dashboard"))

    parts = SparePart.all()  # every category, so extra parts the customer asked for can be added
    selected_names = ServiceBooking.selected_part_names(booking_id)  # customer's choices
    return render_template("complete_other_booking.html", booking=booking, parts=parts,
                            selected_names=selected_names)


@app.route("/admin/bookings/<int:booking_id>/parts", methods=["GET", "POST"])
@admin_required
def edit_booking_parts(booking_id):
    """Shows the parts the customer chose plus their note, and lets the admin
    add any other part from the catalog (e.g. one the customer asked for in
    the note that belongs to a different service)."""
    try:
        booking = ServiceBooking.get(booking_id)
    except BookingNotFoundError as e:
        flash(str(e), "error")
        return redirect(url_for("admin_dashboard"))
    if booking.status in ("Completed", "Cancelled"):
        flash("Parts can't be changed on a completed or cancelled booking.", "error")
        return redirect(url_for("admin_dashboard"))

    if request.method == "POST":
        try:
            ServiceBooking.set_parts(booking_id, request.form.getlist("part_ids", type=int))
            flash(f"Booking #{booking_id}: parts list updated.", "success")
            return redirect(url_for("admin_dashboard"))
        except ValueError as e:
            flash(str(e), "error")

    groups = {}
    for part in SparePart.all():
        groups.setdefault(part.category, []).append(part)
    return render_template("edit_booking_parts.html", booking=booking, groups=groups,
                            selected_names=ServiceBooking.selected_part_names(booking_id))


@app.route("/admin/analytics")
@admin_required
def admin_analytics():
    return render_template(
        "analytics.html",
        status_chart=analytics.status_breakdown_chart(),
        service_chart=analytics.service_type_chart(),
        daily_chart=analytics.bookings_per_day_chart(),
    )


@app.route("/admin/export-csv")
@admin_required
def export_csv():
    """Exports every booking to a CSV file the browser downloads — a further
    demonstration of file handling (Syllabus Module 5.1)."""
    bookings = ServiceBooking.find_all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Booking ID", "Customer", "Phone", "Vehicle", "Registration No.",
                      "Service Type", "Date", "Time Slot", "Bay", "Mechanic", "Status",
                      "Service Price", "Parts Estimate", "Pickup Required", "Pickup Fee",
                      "Invoice Total", "Notes"])
    for b in bookings:
        writer.writerow([b.id, b.customer_name, b.customer_phone, f"{b.brand} {b.model}",
                          b.registration_number, b.service_type, b.preferred_date, b.time_slot,
                          b.bay_number, b.mechanic_name or "Not assigned", b.status, b.service_price, b.parts_estimate,
                          "Yes" if b.pickup_required else "No", b.pickup_fee,
                          b.invoice_total, b.notes or ""])
    database.log_event("Admin exported all bookings to CSV")
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=service_bookings.csv"},
    )


@app.route("/admin/pricing", methods=["GET", "POST"])
@admin_required
def admin_pricing():
    if request.method == "POST":
        for service_type in SERVICE_TYPES:
            raw_price = request.form.get(f"price_{service_type}")
            try:
                new_price = float(raw_price)
                if new_price < 0:
                    raise ValueError
                ServicePricing.update_price(service_type, new_price)
            except (TypeError, ValueError):
                flash(f"Skipped '{service_type}' — enter a valid non-negative price.", "error")
        raw_fee = request.form.get("pickup_fee")
        try:
            fee = float(raw_fee)
            if fee < 0:
                raise ValueError
            GarageSettings.set_pickup_fee(fee)
        except (TypeError, ValueError):
            flash("Skipped doorstep pickup price — enter a valid non-negative price.", "error")
        flash("Pricing updated.", "success")
        return redirect(url_for("admin_pricing"))

    return render_template("admin_pricing.html", service_prices=ServicePricing.all(),
                           pickup_fee_value=GarageSettings.get_pickup_fee())


@app.route("/admin/spare-parts")
@admin_required
def admin_spare_parts():
    parts_by_category = {service: SparePart.by_category(service) for service in SERVICE_TYPES}
    return render_template("admin_spare_parts.html", parts_by_category=parts_by_category,
                            vendors=VENDORS, recent_purchases=SparePart.recent_purchases())


@app.route("/admin/spare-parts/add", methods=["GET", "POST"])
@admin_required
def add_spare_part():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        category = request.form.get("category")
        try:
            price = float(request.form.get("price", ""))
            stock_qty = int(request.form.get("stock_qty", "0"))
        except ValueError:
            price = None
            stock_qty = None

        if not name or category not in SERVICE_TYPES or price is None or price < 0 or stock_qty is None or stock_qty < 0:
            flash("Please provide a valid name, category, price and starting stock.", "error")
        else:
            SparePart.create(name, category, price, stock_qty)
            flash(f"'{name}' added to the spare parts catalog.", "success")
            return redirect(url_for("admin_spare_parts"))

    return render_template("add_spare_part.html", service_types=SERVICE_TYPES)


@app.route("/admin/spare-parts/<int:part_id>/restock", methods=["POST"])
@admin_required
def restock_spare_part(part_id):
    vendor_name = request.form.get("vendor_name")
    try:
        quantity = int(request.form.get("quantity", "0"))
    except ValueError:
        quantity = 0

    vendor = next((v for v in VENDORS if v["name"] == vendor_name), None)
    if vendor is None or quantity <= 0:
        flash("Please choose a vendor and a quantity greater than zero.", "error")
        return redirect(url_for("admin_spare_parts"))

    try:
        part = SparePart.get(part_id)
        unit_cost = round(part.price * vendor["price_multiplier"], 2)
        total_cost = SparePart.restock(part_id, vendor_name, quantity, unit_cost)
        flash(f"Ordered {quantity} x '{part.name}' from {vendor_name} for Rs.{total_cost:.2f}.", "success")
    except SparePartNotFoundError as e:
        flash(str(e), "error")
    return redirect(url_for("admin_spare_parts"))


@app.route("/admin/spare-parts/<int:part_id>/delete", methods=["POST"])
@admin_required
def delete_spare_part(part_id):
    try:
        part = SparePart.get(part_id)
        SparePart.delete(part_id)
        flash(f"'{part.name}' removed from the catalog. Its past purchase orders are still kept.", "success")
    except SparePartNotFoundError as e:
        flash(str(e), "error")
    return redirect(url_for("admin_spare_parts"))


@app.route("/admin/profile", methods=["GET", "POST"])
@admin_required
def admin_profile():
    user = current_user()
    if request.method == "POST" and request.form.get("form_name") == "contact":
        phone = request.form.get("care_phone", "").strip()
        email = request.form.get("care_email", "").strip().lower()
        if not phone or "@" not in email:
            flash("Enter a customer-care phone number and a valid email.", "error")
        else:
            GarageSettings.update_contact(phone, email)
            flash("Customer-care contact details updated. Customers now see the new details.", "success")
            return redirect(url_for("admin_profile"))
    elif request.method == "POST":
        current_password = request.form.get("current_password", "")
        new_email = request.form.get("new_email", "").strip().lower()
        new_password = request.form.get("new_password", "")
        confirm_password = request.form.get("confirm_password", "")

        if new_password and new_password != confirm_password:
            flash("New passwords do not match.", "error")
        elif new_password and len(new_password) < 6:
            flash("New password must be at least 6 characters long.", "error")
        else:
            try:
                User.update_credentials(
                    user.id, current_password,
                    new_email=new_email or None,
                    new_password=new_password or None,
                )
                flash("Your login details have been updated.", "success")
                return redirect(url_for("admin_profile"))
            except InvalidCredentialsError as e:
                flash(str(e), "error")
            except UserAlreadyExistsError as e:
                flash(str(e), "error")

    return render_template("admin_profile.html", user=user, mechanics=Mechanic.all())


@app.route("/admin/mechanics/add", methods=["POST"])
@admin_required
def add_mechanic():
    name = request.form.get("name", "").strip()
    phone = request.form.get("phone", "").strip()
    specialization = request.form.get("specialization", "").strip()
    if not name:
        flash("Enter the mechanic's name.", "error")
    elif not (phone.isascii() and phone.isdigit() and len(phone) == 10):
        flash("The mechanic's mobile number is required and must be exactly 10 digits.", "error")
    else:
        Mechanic.create(name, phone, specialization)
        flash(f"{name} added to your mechanics.", "success")
    return redirect(url_for("admin_profile") + "#mechanics")


@app.route("/admin/mechanics/<int:mechanic_id>/toggle", methods=["POST"])
@admin_required
def toggle_mechanic(mechanic_id):
    try:
        mechanic = Mechanic.get(mechanic_id)
        Mechanic.set_active(mechanic_id, not mechanic.is_active)
        state = "can be assigned again" if not mechanic.is_active else "is deactivated and won't appear when assigning"
        flash(f"{mechanic.name} {state}.", "success")
    except MechanicNotFoundError as e:
        flash(str(e), "error")
    return redirect(url_for("admin_profile") + "#mechanics")


@app.route("/admin/mechanics/<int:mechanic_id>/delete", methods=["POST"])
@admin_required
def delete_mechanic(mechanic_id):
    try:
        mechanic = Mechanic.get(mechanic_id)
        Mechanic.delete(mechanic_id)
        flash(f"{mechanic.name} removed.", "success")
    except (MechanicNotFoundError, MechanicUnavailableError) as e:
        flash(str(e), "error")
    return redirect(url_for("admin_profile") + "#mechanics")


if __name__ == "__main__":
    database.init_db()
    print("=" * 64)
    print(" AutoCare Garage — Vehicle Servicing Management System")
    print(" Database ready -> vehicle_service.db")
    print(" Visit http://127.0.0.1:5000 in your browser")
    print(" (Staff login credentials are set in vehicle_service/database.py")
    print("  and can be changed any time from the admin Profile page.)")
    print("=" * 64)
    app.run(debug=True)
