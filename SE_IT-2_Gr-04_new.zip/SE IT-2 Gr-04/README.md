# AutoCare Garage — Online Vehicle Servicing Management System

A Flask web application built for **ITM301 – Mini Project 1A (Python), Sem III**.
Customers register, add vehicles, and book service appointments against
real-time bay availability, estimated pricing and spare-parts costs, and an
optional pickup service. Staff log in to a separate dashboard to update
booking status, manage pricing and spare-parts stock, view analytics, and
export records.

Default staff/admin login (seeded automatically the first time you run the app):
```
Email:    admin@autocare.com
Password: AutoCare1234
```
This is **not shown anywhere in the app itself** — staff can change both the
email and password any time from `Profile` once logged in.

---

## 1. Requirements

- **Python 3.10 or newer** — [download here](https://www.python.org/downloads/) if you don't have it.
  During installation, tick **"Add Python to PATH"**.

Everything else (Flask, pandas, matplotlib) is installed in step 3 below.

---

## 2. Project structure

```
vehicle_service_system/
├── app.py                   # Flask routes — the web application itself
├── requirements.txt         # Python packages this project needs
├── vehicle_service/         # our own package (Syllabus Module 4 — packages)
│   ├── __init__.py
│   ├── database.py          # SQLite connection, table creation, file logging
│   ├── models.py            # User / Vehicle / ServiceBooking classes (OOP, Module 3)
│   ├── exceptions.py        # Custom exceptions (Module 4)
│   ├── notifications.py     # Background-thread booking confirmations (Module 4)
│   └── analytics.py         # Pandas + Matplotlib charts for the admin (Module 6)
├── templates/                # HTML pages (Jinja2 templates)
├── static/style.css          # All styling
├── vehicle_service.db        # created automatically the first time you run it
└── activity.log              # created automatically — a plain-text audit trail
```

---

## 3. Set up and run (Windows)

Open **Command Prompt** or **PowerShell**, then:

```cmd
:: 1. Move into the project folder (adjust the path to wherever you unzipped it)
cd Downloads\vehicle_service_system

:: 2. Create a virtual environment (keeps this project's packages separate)
python -m venv venv

:: 3. Activate it
venv\Scripts\activate

:: 4. Install the required packages
pip install -r requirements.txt

:: 5. Run the application
python app.py
```

### What the terminal should show

```
================================================================
 AutoCare Garage — Vehicle Servicing Management System
 Database ready -> vehicle_service.db
 Visit http://127.0.0.1:5000 in your browser
 (Staff login credentials are set in vehicle_service/database.py
  and can be changed any time from the admin Profile page.)
================================================================
 * Serving Flask app 'app'
 * Debug mode: on
 * Running on http://127.0.0.1:5000
Press CTRL+C to quit
 * Restarting with stat
 * Debugger is active!
```

Now open **http://127.0.0.1:5000** in your browser (Chrome, Edge, Firefox — any of them).

To stop the server later, go back to the terminal window and press `Ctrl + C`.

Next time you want to run it, you only need steps 3 and 5 (activate the
virtual environment, then `python app.py`) — you don't need to reinstall
packages every time.

---

## 4. Using the app

**As a customer:**
1. Sign up on the home page.
2. Add a vehicle (`Vehicles → Add vehicle`) — the garage services cars only,
   so the vehicle type is fixed.
3. Go to `Book Service`, pick a date, check the live bay-availability table
   and the estimated charges table (labor + typical spare parts per service
   type), choose a free time slot, and optionally tick **Pickup Required**
   (+ Rs. 300 — an address field appears and a running total updates live).
   Tick only the **spare parts you want changed** (the total updates live; you pay only for what you pick), then confirm to book. A confirmation is sent on a background thread — watch
   the terminal window a couple of seconds later for a `[Notification
   Thread] ...` line.
4. View or cancel bookings under `My Bookings`. Once staff mark a booking
   **Completed**, its **Invoice** column shows the final estimated total
   (service + spare parts + pickup, if any).
5. `Spare Parts` shows the parts catalog and stock status for each service
   type, so you know what's typically needed before you book.
6. `Profile` lets you change your password (current password required to
   confirm) and is also where `Delete my account` now lives.
7. `My Bookings → View invoice` opens a printable invoice/receipt once a
   booking is marked Completed — itemized for "Other" jobs (the exact parts
   used), or a labor + estimated-parts breakdown for General Service/Oil
   Change.

**As staff:**
1. `Bookings` shows every customer's bookings, including pickup address and
   invoice total; filter by status or change a booking's status with the
   dropdown (`Confirmed → In Progress → Completed`). **"Other" bookings work
   differently** — the dropdown only offers Confirmed/In Progress/Cancelled;
   completing one requires the **"Complete & select parts"** button, which
   opens a checklist of that job's spare parts. Whichever you tick get
   priced into the invoice and have their stock reduced by one unit.
2. **Mechanics** — go to `Profile → Mechanics` to add your mechanics (name, phone,
   specialty). On `Bookings`, pick a mechanic from the **Mechanic** dropdown on each
   Confirmed / In Progress job. A booking **can't be moved to In Progress or Completed
   until a mechanic is assigned**, and a mechanic can't be given two jobs in the same
   date + time slot. Customers see the assigned mechanic's name and phone on their
   Dashboard, My Bookings and invoice ("To be assigned" until then). Mechanics who
   already appear on a booking can be deactivated but not deleted, so history stays
   accurate.
3. **Customer-care contact** — `Profile → Garage customer-care contact` sets the phone and email customers see in the footer, dashboard and invoices. It can only be changed here.
4. Whenever a part drops below 5 in stock (or hits 0), every admin page
   shows an orange **stock alert banner** at the top — customers never see
   this — linking straight to `Spare Parts` to restock it.
4. `Spare Parts` lists the full parts catalog by category with live stock
   levels. When a part is low or out of stock, order more from one of three
   simulated vendors (each with its own price) — stock updates immediately
   and the order is logged under "Recent purchase orders". You can also add
   brand-new parts to the catalog here.
5. `Pricing` lets you edit the labor charge for each service type. Changes
   only apply to bookings made *after* the change — existing invoices are
   never rewritten.
6. `Analytics` shows three charts built with pandas + Matplotlib: bookings by
   status, service-type distribution, and bookings per date.
7. `Profile` lets you change the staff login email and/or password (you'll
   need your current password to confirm).
8. `Export CSV` downloads every booking — including pricing and invoice
   columns — as a spreadsheet-ready CSV file.

---

## 5. How this maps to your syllabus

| Syllabus module | Where it's used |
|---|---|
| **Module 1 — Fundamentals of Python** | Variables, conditionals, loops, functions throughout `app.py` and `vehicle_service/*.py` |
| **Module 2 — Functions & Data structures** | Functions in every route/model method; lists/dicts used for slot availability, chart data, etc. |
| **Module 3 — OOP** | `User`, `Vehicle`, `ServiceBooking` classes in `models.py`, with constructors and classmethods |
| **Module 4 — Packages, multithreading, exceptions** | `vehicle_service` is a custom package; `notifications.py` uses `threading.Thread`; `exceptions.py` defines user-defined exceptions used with try/except across the app |
| **Module 5 — File handling, GUI & database** | `database.py` does CRUD with `sqlite3`; `activity.log` is written with plain file I/O; CSV export uses the `csv` module; the "GUI" is the Flask/HTML web interface |
| **Module 6 — Data visualization, web frameworks** | `analytics.py` uses **pandas** to aggregate booking data and **Matplotlib** to chart it; the whole app is a **Flask** web application |

---

## 6. Troubleshooting

- **`'python' is not recognized...`** — Python isn't on PATH. Reinstall
  Python and tick "Add Python to PATH", or use `py` instead of `python`.
- **`pip install` fails / no internet** — you need an internet connection
  the first time you install packages; after that the app runs fully offline.
- **Port already in use** — close any other running `python app.py`, or
  edit the last line of `app.py` to `app.run(debug=True, port=5050)` and
  visit `http://127.0.0.1:5050` instead.
- **Want to start with a clean database** — close the server, delete
  `vehicle_service.db` and `activity.log`, then run `python app.py` again;
  they'll be recreated automatically (including the admin account).


## Vehicle delivery / collection
When a service is Completed the customer sees a **Delivery** option on the Dashboard and My Bookings:
- **Yes** - enter an address; the car is marked *Delivered* automatically 10 minutes after the customer confirms.
- **No** - pick a date and time slot; the car is marked *Collected* automatically 10 minutes after the slot begins.
- The admin can set the outcome by hand at any time from the Delivery column: *Delivered*, *Collected*, or *Customer didn't come* (self pickup only).
  A missed pickup shows the customer **Book new time**.
- The 10-minute delay is `AUTO_HANDOVER_MINUTES` in `vehicle_service/models.py`.

## Admin settings and booking rules
- **Doorstep pickup price** - Admin -> Pricing, next to the service prices. Saved in the database and used on the home page, booking page and new invoices.
- **Service prices** - Admin -> Pricing. Saved in the database; they stay as set until changed.
- **Real-time slots** - a slot that has already ended (by the server's clock) can't be booked. The slot currently under way and later slots can.
- **Customer note** - shown in the admin *All service bookings* table.
- **Edit parts** - on any open booking the admin can open *Edit parts*, see the customer's chosen parts and note, and add parts from any category.
- **One car, one slot** - a vehicle can't be booked for a second service in the same date and time slot (cancelled bookings don't count); the customer gets a pop-up.
- **Choose a mechanic** - when booking, the customer picks *Any available mechanic* (admin assigns one later) or a specific mechanic shown with name, mobile number and specialty. A specific mechanic is assigned straight away unless they're already booked in that slot. Mechanics must have a 10-digit mobile number.
- **Mechanic not available** - if the mechanic a customer chose is busy in that slot (or is later deactivated by the admin), the customer sees a pop-up on their dashboard at login with two options: *Assign a different mechanic* (the garage picks a free one) or *Rearrange the service* (choose a new date/slot, optionally another mechanic). The admin table tags these bookings until the customer decides.
