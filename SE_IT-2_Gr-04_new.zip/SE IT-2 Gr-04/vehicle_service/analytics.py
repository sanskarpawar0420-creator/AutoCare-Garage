"""
Admin analytics dashboard.

Demonstrates Data Visualization & Analysis (Syllabus Module 6 — "Visualization
using Matplotlib... Data manipulation and analysis using Pandas"). Booking
rows are loaded into a pandas DataFrame, aggregated, and rendered with
Matplotlib. Each chart is returned as a base64 PNG string so it can be
embedded directly in an HTML <img> tag without saving files to disk.
"""
import base64
import io

import matplotlib

matplotlib.use("Agg")  # non-interactive backend — required inside a web server
import matplotlib.pyplot as plt
import pandas as pd

from .models import ServiceBooking

CHART_COLOR = "#3b7dbf"
BAR_COLOR = "#1f4e79"


def _fig_to_base64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight", dpi=110)
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("utf-8")


def bookings_dataframe():
    """Load every booking into a pandas DataFrame for aggregation."""
    bookings = ServiceBooking.find_all()
    records = [
        {
            "status": b.status,
            "preferred_date": b.preferred_date,
            "service_type": b.service_type,
            "time_slot": b.time_slot,
        }
        for b in bookings
    ]
    return pd.DataFrame(records)


def status_breakdown_chart():
    df = bookings_dataframe()
    if df.empty:
        return None
    counts = df["status"].value_counts()
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.bar(counts.index, counts.values, color=BAR_COLOR)
    ax.set_title("Bookings by Status")
    ax.set_ylabel("Number of Bookings")
    ax.spines[["top", "right"]].set_visible(False)
    plt.xticks(rotation=15)
    return _fig_to_base64(fig)


def service_type_chart():
    df = bookings_dataframe()
    if df.empty:
        return None
    counts = df["service_type"].value_counts()
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.pie(counts.values, labels=counts.index, autopct="%1.0f%%", startangle=90,
           colors=plt.cm.Set2.colors)
    ax.set_title("Service Type Distribution")
    return _fig_to_base64(fig)


def bookings_per_day_chart():
    df = bookings_dataframe()
    if df.empty:
        return None
    daily = df.groupby("preferred_date").size().sort_index()
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(daily.index, daily.values, marker="o", color=CHART_COLOR, linewidth=2)
    ax.set_title("Bookings per Date")
    ax.set_ylabel("Bookings")
    ax.spines[["top", "right"]].set_visible(False)
    plt.xticks(rotation=45, ha="right")
    return _fig_to_base64(fig)
