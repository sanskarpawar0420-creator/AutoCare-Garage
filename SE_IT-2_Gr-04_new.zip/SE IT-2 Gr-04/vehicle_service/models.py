"""
Domain models: User, Vehicle, ServiceBooking, ServicePricing, SparePart.

Demonstrates Object-Oriented Programming (Syllabus Module 3 — "Object
oriented programming concepts, Creating Classes and Objects, Constructors")
by wrapping every database row in a class with a constructor, and grouping
each entity's CRUD logic behind classmethods instead of scattering raw SQL
through the Flask routes.
"""
import datetime

from werkzeug.security import check_password_hash, generate_password_hash

from . import database
from .exceptions import (
    VehicleAlreadyBookedError,
    SlotPassedError,
    BookingNotFoundError,
    InvalidCredentialsError,
    MechanicNotAssignedError,
    MechanicNotFoundError,
    MechanicUnavailableError,
    NoBayAvailableError,
    SparePartNotFoundError,
    UserAlreadyExistsError,
    VehicleNotFoundError,
)

# Service-bay configuration: 5 physical bays, 5 booking slots per day.
# ServiceBooking.slot_availability() uses these to answer "how many bays
# are free right now?" — the real-time bay availability feature.
TIME_SLOTS = ["09:00 - 11:00", "11:00 - 13:00", "13:00 - 15:00", "15:00 - 17:00", "17:00 - 19:00"]
BAYS_PER_SLOT = 5

# Flat estimated pickup charge, added to a booking's invoice when the
# customer ticks "Pickup Required".
PICKUP_FEE = 300.0


class User:
    """Represents one customer or staff account."""

    def __init__(self, id, full_name, email, phone, password_hash, is_admin, created_at=None):
        self.id = id
        self.full_name = full_name
        self.email = email
        self.phone = phone
        self.password_hash = password_hash
        self.is_admin = bool(is_admin)
        self.created_at = created_at

    @staticmethod
    def _from_row(row):
        if row is None:
            return None
        return User(row["id"], row["full_name"], row["email"], row["phone"],
                     row["password_hash"], row["is_admin"], row["created_at"])

    @classmethod
    def register(cls, full_name, email, phone, password):
        """Create a new account. Raises UserAlreadyExistsError on a duplicate email."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT id FROM users WHERE email = ?", (email,))
            if cur.fetchone() is not None:
                raise UserAlreadyExistsError(f"An account with email '{email}' already exists.")
            cur.execute(
                "INSERT INTO users (full_name, email, phone, password_hash) VALUES (?, ?, ?, ?)",
                (full_name, email, phone, generate_password_hash(password)),
            )
            conn.commit()
            database.log_event(f"New account registered: {email}")
            return cur.lastrowid
        finally:
            conn.close()

    @classmethod
    def authenticate(cls, email, password):
        """Return the matching User, or raise InvalidCredentialsError."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE email = ?", (email,))
            user = cls._from_row(cur.fetchone())
            if user is None or not check_password_hash(user.password_hash, password):
                raise InvalidCredentialsError("Incorrect email or password.")
            database.log_event(f"Login: {email}")
            return user
        finally:
            conn.close()

    @classmethod
    def get_by_id(cls, user_id):
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
            return cls._from_row(cur.fetchone())
        finally:
            conn.close()

    @classmethod
    def update_credentials(cls, user_id, current_password, new_email=None, new_password=None):
        """Used by the admin profile page to change the staff login email
        and/or password. Requires the current password as confirmation."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
            user = cls._from_row(cur.fetchone())
            if user is None or not check_password_hash(user.password_hash, current_password):
                raise InvalidCredentialsError("Current password is incorrect.")

            updates, params = [], []
            if new_email and new_email != user.email:
                cur.execute("SELECT id FROM users WHERE email = ? AND id != ?", (new_email, user_id))
                if cur.fetchone() is not None:
                    raise UserAlreadyExistsError(f"Email '{new_email}' is already in use.")
                updates.append("email = ?")
                params.append(new_email)
            if new_password:
                updates.append("password_hash = ?")
                params.append(generate_password_hash(new_password))

            if updates:
                params.append(user_id)
                conn.execute(f"UPDATE users SET {', '.join(updates)} WHERE id = ?", params)
                conn.commit()
                database.log_event(f"Login credentials updated for user_id={user_id}")
        finally:
            conn.close()

    def delete(self):
        """Permanently delete this account. Vehicles and bookings cascade-delete
        automatically because of the ON DELETE CASCADE foreign keys."""
        conn = database.get_connection()
        try:
            conn.execute("DELETE FROM users WHERE id = ?", (self.id,))
            conn.commit()
            database.log_event(f"Account permanently deleted: {self.email}")
        finally:
            conn.close()


class Vehicle:
    """Represents one vehicle registered by a customer."""

    def __init__(self, id, user_id, vehicle_type, brand, model, registration_number,
                 year, created_at=None):
        self.id = id
        self.user_id = user_id
        self.vehicle_type = vehicle_type
        self.brand = brand
        self.model = model
        self.registration_number = registration_number
        self.year = year
        self.created_at = created_at

    @staticmethod
    def _from_row(row):
        if row is None:
            return None
        return Vehicle(row["id"], row["user_id"], row["vehicle_type"], row["brand"],
                        row["model"], row["registration_number"], row["year"], row["created_at"])

    @classmethod
    def create(cls, user_id, vehicle_type, brand, model, registration_number, year):
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO vehicles (user_id, vehicle_type, brand, model, "
                "registration_number, year) VALUES (?, ?, ?, ?, ?, ?)",
                (user_id, vehicle_type, brand, model, registration_number, year or None),
            )
            conn.commit()
            database.log_event(f"Vehicle added: {registration_number} (user_id={user_id})")
            return cur.lastrowid
        finally:
            conn.close()

    @classmethod
    def find_by_user(cls, user_id):
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM vehicles WHERE user_id = ? ORDER BY created_at DESC", (user_id,))
            return [cls._from_row(r) for r in cur.fetchall()]
        finally:
            conn.close()

    @classmethod
    def get_owned(cls, vehicle_id, user_id):
        """Fetch a vehicle only if it belongs to this user; otherwise raise."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM vehicles WHERE id = ? AND user_id = ?", (vehicle_id, user_id))
            vehicle = cls._from_row(cur.fetchone())
            if vehicle is None:
                raise VehicleNotFoundError("Vehicle not found for this account.")
            return vehicle
        finally:
            conn.close()

    @classmethod
    def delete(cls, vehicle_id, user_id):
        vehicle = cls.get_owned(vehicle_id, user_id)  # ownership check first
        conn = database.get_connection()
        try:
            conn.execute("DELETE FROM vehicles WHERE id = ?", (vehicle.id,))
            conn.commit()
            database.log_event(f"Vehicle deleted: {vehicle.registration_number}")
        finally:
            conn.close()


# A scheduled delivery/collection completes automatically this many minutes
# after its time (the admin can still set the outcome by hand before then).
AUTO_HANDOVER_MINUTES = 10


class ServiceBooking:
    """Represents one service appointment for one vehicle.

    Pricing (service_price, parts_estimate, pickup_fee) is snapshotted at the
    moment the booking is created, so a later change to service pricing or
    spare-parts stock never silently rewrites a customer's existing invoice.
    """

    def __init__(self, id, user_id, vehicle_id, service_type, preferred_date, time_slot,
                 bay_number, status, notes, created_at=None,
                 service_price=0.0, parts_estimate=0.0, pickup_required=0,
                 pickup_address=None, pickup_fee=0.0, mechanic_id=None,
                 delivery_option=None, delivery_address=None, collect_date=None,
                 collect_slot=None, delivery_status=None, missed_count=0,
                 handover_due=None, mechanic_requested=0, mechanic_issue=0, **extra):
        self.id = id
        self.user_id = user_id
        self.vehicle_id = vehicle_id
        self.service_type = service_type
        self.preferred_date = preferred_date
        self.time_slot = time_slot
        self.bay_number = bay_number
        self.status = status
        self.notes = notes
        self.created_at = created_at
        self.service_price = service_price or 0.0
        self.parts_estimate = parts_estimate or 0.0
        self.pickup_required = bool(pickup_required)
        self.pickup_address = pickup_address
        self.pickup_fee = pickup_fee or 0.0
        self.mechanic_id = mechanic_id
        self.delivery_option = delivery_option
        self.delivery_address = delivery_address
        self.collect_date = collect_date
        self.collect_slot = collect_slot
        self.delivery_status = delivery_status
        self.missed_count = missed_count or 0
        self.handover_due = handover_due
        self.mechanic_requested = bool(mechanic_requested)
        self.mechanic_issue = bool(mechanic_issue)
        # Filled in by JOIN queries when a mechanic is assigned
        self.mechanic_name = None
        self.mechanic_phone = None
        self.mechanic_specialization = None
        # Extra columns pulled in by JOIN queries (vehicle/customer details)
        for key, value in extra.items():
            setattr(self, key, value)

    @property
    def invoice_total(self):
        """Estimated total: service labor + spare parts + pickup, as they
        stood at the moment this booking was placed."""
        return round(self.service_price + self.parts_estimate + self.pickup_fee, 2)

    @staticmethod
    def _from_row(row):
        return ServiceBooking(**dict(row)) if row is not None else None

    @classmethod
    def busy_mechanic_slots(cls, day):
        """{mechanic_id: [slots]} where that mechanic already has a job on `day`."""
        conn = database.get_connection()
        try:
            rows = conn.execute(
                "SELECT mechanic_id, time_slot FROM service_bookings WHERE preferred_date = ? "
                "AND mechanic_id IS NOT NULL AND status NOT IN ('Cancelled', 'Completed')", (day,)).fetchall()
            result = {}
            for r in rows:
                result.setdefault(r["mechanic_id"], []).append(r["time_slot"])
            return result
        finally:
            conn.close()

    @classmethod
    def slot_has_passed(cls, day, slot):
        """True if the slot has already ended (so it can't be booked).
        A slot that is under way right now can still be booked."""
        try:
            return cls._slot_end(day, slot) <= datetime.datetime.now()
        except (ValueError, TypeError, IndexError):
            return True

    @classmethod
    def passed_slots(cls, day):
        return {slot for slot in TIME_SLOTS if cls.slot_has_passed(day, slot)}

    @classmethod
    def slot_availability(cls, preferred_date):
        """Return {time_slot: bays_still_free} for a given date.
        This backs the 'real-time bay availability' feature from the project
        objectives — customers see live capacity before they book."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            availability = {}
            for slot in TIME_SLOTS:
                cur.execute(
                    "SELECT COUNT(*) AS taken FROM service_bookings "
                    "WHERE preferred_date = ? AND time_slot = ? AND status != 'Cancelled'",
                    (preferred_date, slot),
                )
                taken = cur.fetchone()["taken"]
                availability[slot] = max(0, BAYS_PER_SLOT - taken)
            return availability
        finally:
            conn.close()

    @classmethod
    def create(cls, user_id, vehicle_id, service_type, preferred_date, time_slot, notes,
               pickup_required=False, pickup_address=None, part_ids=None, mechanic_id=None):
        """Book a bay for the given slot, or raise NoBayAvailableError if full.
        Also snapshots the current service price and the spare parts the
        customer chose (part_ids), so the price reflects their own selection."""
        if time_slot not in TIME_SLOTS:
            raise SlotPassedError("Please choose a valid time slot.")
        if cls.slot_has_passed(preferred_date, time_slot):
            raise SlotPassedError(
                "That time slot has already passed. Please choose the current or a later slot."
            )
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            # The same car can't have two services (of any type) in the same slot.
            cur.execute(
                "SELECT service_type FROM service_bookings WHERE vehicle_id = ? "
                "AND preferred_date = ? AND time_slot = ? AND status != 'Cancelled'",
                (vehicle_id, preferred_date, time_slot),
            )
            clash = cur.fetchone()
            if clash is not None:
                raise VehicleAlreadyBookedError(
                    f"This car's service is already booked for {preferred_date} ({time_slot}) "
                    f"- {clash['service_type']}. Please choose a different time slot or date."
                )
            cur.execute(
                "SELECT COUNT(*) AS taken FROM service_bookings "
                "WHERE preferred_date = ? AND time_slot = ? AND status != 'Cancelled'",
                (preferred_date, time_slot),
            )
            taken = cur.fetchone()["taken"]
            if taken >= BAYS_PER_SLOT:
                raise NoBayAvailableError(
                    f"All {BAYS_PER_SLOT} bays are already booked for {preferred_date} "
                    f"({time_slot}). Please choose a different slot."
                )
            bay_number = taken + 1

            cur.execute("SELECT price FROM service_pricing WHERE service_type = ?", (service_type,))
            price_row = cur.fetchone()
            service_price = price_row["price"] if price_row else 0.0

            # Parts the customer chose (must belong to this service's category
            # and be in stock). Choosing fewer parts lowers the estimate.
            chosen_parts = []
            for part_id in dict.fromkeys(part_ids or []):
                cur.execute("SELECT name, price, stock_qty FROM spare_parts WHERE id = ? AND category = ?",
                            (part_id, service_type))
                part = cur.fetchone()
                if part is not None and part["stock_qty"] > 0:
                    chosen_parts.append(part)
            parts_estimate = sum(p["price"] for p in chosen_parts)

            pickup_fee = GarageSettings.get_pickup_fee() if pickup_required else 0.0

            # Customer asked for a specific mechanic (None = any mechanic; admin assigns later).
            # If that mechanic is deactivated or already busy in this slot the booking is still
            # made, but flagged so the customer is asked what to do (assign another / rearrange).
            mechanic_requested = 0
            mechanic_issue = 0
            if mechanic_id:
                cur.execute("SELECT name, is_active FROM mechanics WHERE id = ?", (mechanic_id,))
                mech = cur.fetchone()
                if mech is None:
                    raise MechanicNotFoundError("That mechanic does not exist.")
                mechanic_requested = 1
                busy = cur.execute(
                    "SELECT id FROM service_bookings WHERE mechanic_id = ? AND preferred_date = ? "
                    "AND time_slot = ? AND status NOT IN ('Cancelled', 'Completed')",
                    (mechanic_id, preferred_date, time_slot),
                ).fetchone()
                if not mech["is_active"] or busy is not None:
                    mechanic_id = None
                    mechanic_issue = 1
            else:
                mechanic_id = None

            cur.execute(
                "INSERT INTO service_bookings (user_id, vehicle_id, service_type, preferred_date, "
                "time_slot, bay_number, notes, service_price, parts_estimate, pickup_required, "
                "pickup_address, pickup_fee, mechanic_id, mechanic_requested, mechanic_issue) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (user_id, vehicle_id, service_type, preferred_date, time_slot, bay_number, notes,
                 service_price, parts_estimate, int(bool(pickup_required)),
                 pickup_address if pickup_required else None, pickup_fee,
                 mechanic_id, mechanic_requested, mechanic_issue),
            )
            booking_id = cur.lastrowid
            for part in chosen_parts:
                conn.execute(
                    "INSERT INTO booking_parts (booking_id, part_name, part_price) VALUES (?, ?, ?)",
                    (booking_id, part["name"], part["price"]),
                )
            conn.commit()
            database.log_event(
                f"Booking #{booking_id} created: user_id={user_id}, {preferred_date} "
                f"{time_slot}, bay {bay_number}, pickup={bool(pickup_required)}"
            )
            return booking_id, bay_number
        finally:
            conn.close()

    @classmethod
    def find_by_user(cls, user_id):
        cls.sync_handovers()
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT sb.*, v.brand, v.model, v.registration_number, "
                "m.name AS mechanic_name, m.phone AS mechanic_phone, "
                "m.specialization AS mechanic_specialization "
                "FROM service_bookings sb JOIN vehicles v ON sb.vehicle_id = v.id "
                "LEFT JOIN mechanics m ON sb.mechanic_id = m.id "
                "WHERE sb.user_id = ? ORDER BY sb.preferred_date DESC, sb.created_at DESC",
                (user_id,),
            )
            return [cls._from_row(r) for r in cur.fetchall()]
        finally:
            conn.close()

    @classmethod
    def find_all(cls):
        """Used by the admin dashboard to see every booking across all customers."""
        cls.sync_handovers()
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT sb.*, v.brand, v.model, v.registration_number, "
                "u.full_name AS customer_name, u.phone AS customer_phone, "
                "m.name AS mechanic_name, m.phone AS mechanic_phone, "
                "m.specialization AS mechanic_specialization "
                "FROM service_bookings sb "
                "JOIN vehicles v ON sb.vehicle_id = v.id "
                "JOIN users u ON sb.user_id = u.id "
                "LEFT JOIN mechanics m ON sb.mechanic_id = m.id "
                "ORDER BY sb.preferred_date DESC, sb.created_at DESC"
            )
            return [cls._from_row(r) for r in cur.fetchall()]
        finally:
            conn.close()

    @classmethod
    def get(cls, booking_id):
        """Fetch one booking (with vehicle/customer details) by id — used by
        the invoice page and the 'complete an Other job' admin flow."""
        cls.sync_handovers()
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT sb.*, v.brand, v.model, v.registration_number, "
                "u.full_name AS customer_name, u.phone AS customer_phone, u.email AS customer_email, "
                "m.name AS mechanic_name, m.phone AS mechanic_phone, "
                "m.specialization AS mechanic_specialization "
                "FROM service_bookings sb "
                "JOIN vehicles v ON sb.vehicle_id = v.id "
                "JOIN users u ON sb.user_id = u.id "
                "LEFT JOIN mechanics m ON sb.mechanic_id = m.id "
                "WHERE sb.id = ?",
                (booking_id,),
            )
            booking = cls._from_row(cur.fetchone())
            if booking is None:
                raise BookingNotFoundError(f"Booking #{booking_id} does not exist.")
            return booking
        finally:
            conn.close()

    # ---------------------------------------------------- delivery / collection --
    @staticmethod
    def _slot_end(day, slot):
        """datetime when a collection slot such as '11:00 - 13:00' ends."""
        end = slot.split("-")[1].strip()
        return datetime.datetime.strptime(f"{day} {end}", "%Y-%m-%d %H:%M")

    @classmethod
    def sync_handovers(cls):
        """Pending deliveries/collections whose due time has passed complete
        automatically: home delivery -> 'Delivered', self pickup -> 'Collected'."""
        conn = database.get_connection()
        try:
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            rows = conn.execute(
                "SELECT id, delivery_option FROM service_bookings "
                "WHERE delivery_status = 'Pending' AND handover_due IS NOT NULL AND handover_due <= ?",
                (now,),
            ).fetchall()
            for row in rows:
                new_status = "Delivered" if row["delivery_option"] == "Home Delivery" else "Collected"
                conn.execute("UPDATE service_bookings SET delivery_status = ? WHERE id = ?",
                             (new_status, row["id"]))
                database.log_event(f"Booking #{row['id']}: vehicle {new_status.lower()} automatically")
            conn.commit()
        finally:
            conn.close()

    @classmethod
    def set_delivery(cls, booking_id, user_id, home_delivery, delivery_address=None,
                     collect_date=None, collect_slot=None):
        """Customer's choice once the service is Completed.
        home_delivery=True  -> we deliver the car to delivery_address.
        home_delivery=False -> customer collects it in the chosen date/slot.
        Can be (re)submitted until the car is delivered/collected, which is how
        a missed collection gets a new time."""
        booking = cls.get(booking_id)
        if booking.user_id != user_id:
            raise BookingNotFoundError(f"Booking #{booking_id} does not exist.")
        if booking.status != "Completed":
            raise ValueError("Delivery can be chosen only after the service is completed.")
        if booking.delivery_status in ("Delivered", "Collected"):
            raise ValueError("This vehicle has already been handed over.")

        if home_delivery:
            if not delivery_address:
                raise ValueError("Please enter the address where the vehicle should be delivered.")
            values = ("Home Delivery", delivery_address, None, None)
        else:
            if collect_slot not in TIME_SLOTS:
                raise ValueError("Please choose a pickup time slot.")
            try:
                ends = cls._slot_end(collect_date, collect_slot)
            except (ValueError, TypeError):
                raise ValueError("Please choose a valid pickup date.")
            if ends <= datetime.datetime.now():
                raise ValueError("That pickup time has already passed. Please choose a later slot.")
            values = ("Self Pickup", None, collect_date, collect_slot)

        # Home delivery: due 10 min after the customer confirms.
        # Self pickup: 10 min after the slot starts (or after confirming, if
        # the slot has already begun).
        now = datetime.datetime.now()
        start = now
        if not home_delivery:
            slot_start = datetime.datetime.strptime(
                f"{collect_date} {collect_slot.split('-')[0].strip()}", "%Y-%m-%d %H:%M")
            start = max(now, slot_start)
        due = (start + datetime.timedelta(minutes=AUTO_HANDOVER_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")

        conn = database.get_connection()
        try:
            conn.execute(
                "UPDATE service_bookings SET delivery_option = ?, delivery_address = ?, "
                "collect_date = ?, collect_slot = ?, delivery_status = 'Pending', handover_due = ? WHERE id = ?",
                values + (due, booking_id),
            )
            conn.commit()
            database.log_event(f"Booking #{booking_id}: customer chose {values[0]}")
        finally:
            conn.close()

    @classmethod
    def mark_handed_over(cls, booking_id, outcome):
        """Admin sets the result for a booking's delivery/collection:
        'Delivered', 'Collected', or 'Missed' (customer didn't turn up for a
        self pickup, so they are asked to book a new time)."""
        if outcome not in ("Delivered", "Collected", "Missed"):
            raise ValueError("Choose Delivered, Collected or Missed.")
        booking = cls.get(booking_id)
        if booking.delivery_option is None or booking.delivery_status in ("Delivered", "Collected"):
            raise ValueError("No pending delivery/collection for this booking.")
        if outcome == "Missed" and booking.delivery_option != "Self Pickup":
            raise ValueError("Only a self pickup can be marked as missed.")
        conn = database.get_connection()
        try:
            if outcome == "Missed":
                conn.execute("UPDATE service_bookings SET delivery_status = 'Missed', "
                             "missed_count = COALESCE(missed_count, 0) + 1 WHERE id = ?", (booking_id,))
            else:
                conn.execute("UPDATE service_bookings SET delivery_status = ? WHERE id = ?",
                             (outcome, booking_id))
            conn.commit()
            database.log_event(f"Booking #{booking_id}: marked '{outcome}' by admin")
        finally:
            conn.close()
        return outcome

    @property
    def needs_delivery_choice(self):
        """True when the customer should be shown the delivery question."""
        return self.status == "Completed" and self.delivery_status in (None, "Missed")

    @classmethod
    def update_status(cls, booking_id, new_status):
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT id, mechanic_id FROM service_bookings WHERE id = ?", (booking_id,))
            row = cur.fetchone()
            if row is None:
                raise BookingNotFoundError(f"Booking #{booking_id} does not exist.")
            # A job can only start (or finish) once an admin has assigned a mechanic.
            if new_status in ("In Progress", "Completed") and row["mechanic_id"] is None:
                raise MechanicNotAssignedError(
                    f"Assign a mechanic to booking #{booking_id} before marking it {new_status}."
                )
            conn.execute("UPDATE service_bookings SET status = ? WHERE id = ?", (new_status, booking_id))
            conn.commit()
            database.log_event(f"Booking #{booking_id} status changed to '{new_status}'")
        finally:
            conn.close()

    @classmethod
    def assign_mechanic(cls, booking_id, mechanic_id):
        """Admin assigns (or reassigns) a mechanic to an open booking.

        A mechanic can't be given two jobs in the same date + time slot, and
        deactivated mechanics can't be assigned."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM service_bookings WHERE id = ?", (booking_id,))
            booking = cur.fetchone()
            if booking is None:
                raise BookingNotFoundError(f"Booking #{booking_id} does not exist.")
            if booking["status"] not in ("Confirmed", "In Progress"):
                raise MechanicUnavailableError(
                    f"Booking #{booking_id} is {booking['status']} - a mechanic can no longer be changed."
                )

            cur.execute("SELECT * FROM mechanics WHERE id = ?", (mechanic_id,))
            mechanic = cur.fetchone()
            if mechanic is None:
                raise MechanicNotFoundError("That mechanic does not exist.")
            if not mechanic["is_active"]:
                raise MechanicUnavailableError(f"{mechanic['name']} is deactivated and can't be assigned.")

            cur.execute(
                "SELECT id FROM service_bookings WHERE mechanic_id = ? AND preferred_date = ? "
                "AND time_slot = ? AND status NOT IN ('Cancelled', 'Completed') AND id != ?",
                (mechanic_id, booking["preferred_date"], booking["time_slot"], booking_id),
            )
            clash = cur.fetchone()
            if clash is not None:
                raise MechanicUnavailableError(
                    f"{mechanic['name']} is already on booking #{clash['id']} for "
                    f"{booking['preferred_date']} ({booking['time_slot']}). Pick another mechanic."
                )

            conn.execute("UPDATE service_bookings SET mechanic_id = ?, mechanic_issue = 0 WHERE id = ?",
                         (mechanic_id, booking_id))
            conn.commit()
            database.log_event(f"Booking #{booking_id} assigned to mechanic '{mechanic['name']}'")
            return mechanic["name"]
        finally:
            conn.close()

    @classmethod
    def cancel(cls, booking_id, user_id):
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT id FROM service_bookings WHERE id = ? AND user_id = ?",
                        (booking_id, user_id))
            if cur.fetchone() is None:
                raise BookingNotFoundError("Booking not found for this account.")
            conn.execute("UPDATE service_bookings SET status = 'Cancelled' WHERE id = ?", (booking_id,))
            conn.commit()
            database.log_event(f"Booking #{booking_id} cancelled by user_id={user_id}")
        finally:
            conn.close()

    @classmethod
    def complete_with_parts(cls, booking_id, part_ids):
        """Mark an 'Other'-category booking Completed after staff select which
        spare parts were actually used on the job. Each selected part's
        current price is snapshotted into booking_parts (so the invoice stays
        accurate even if the catalog price changes later), its stock is
        reduced by one unit, and the booking's parts_estimate/status are
        updated so the invoice total is generated immediately."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT id, mechanic_id FROM service_bookings WHERE id = ?", (booking_id,))
            row = cur.fetchone()
            if row is None:
                raise BookingNotFoundError(f"Booking #{booking_id} does not exist.")
            if row["mechanic_id"] is None:
                raise MechanicNotAssignedError(
                    f"Assign a mechanic to booking #{booking_id} before completing it."
                )

            # Clear any previous selection (in case staff are editing it)
            conn.execute("DELETE FROM booking_parts WHERE booking_id = ?", (booking_id,))

            total = 0.0
            for part_id in part_ids:
                cur.execute("SELECT name, price, stock_qty FROM spare_parts WHERE id = ?", (part_id,))
                row = cur.fetchone()
                if row is None:
                    continue
                total += row["price"]
                conn.execute(
                    "INSERT INTO booking_parts (booking_id, part_name, part_price) VALUES (?, ?, ?)",
                    (booking_id, row["name"], row["price"]),
                )
                new_qty = max(0, row["stock_qty"] - 1)
                conn.execute("UPDATE spare_parts SET stock_qty = ? WHERE id = ?", (new_qty, part_id))

            conn.execute(
                "UPDATE service_bookings SET status = 'Completed', parts_estimate = ? WHERE id = ?",
                (total, booking_id),
            )
            conn.commit()
            database.log_event(
                f"Booking #{booking_id} completed with {len(part_ids)} part(s), Rs.{total:.2f}"
            )
        finally:
            conn.close()

    @classmethod
    def set_parts(cls, booking_id, part_ids):
        """Admin edits the parts list of an open booking: the customer's own
        choices plus any extra part the customer asked for (e.g. in their
        note) from any category. Prices are snapshotted and the booking's
        parts estimate is updated."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT status FROM service_bookings WHERE id = ?", (booking_id,))
            row = cur.fetchone()
            if row is None:
                raise BookingNotFoundError(f"Booking #{booking_id} does not exist.")
            if row["status"] in ("Completed", "Cancelled"):
                raise ValueError("Parts can't be changed on a completed or cancelled booking.")
            conn.execute("DELETE FROM booking_parts WHERE booking_id = ?", (booking_id,))
            total = 0.0
            for part_id in dict.fromkeys(part_ids):
                cur.execute("SELECT name, price FROM spare_parts WHERE id = ?", (part_id,))
                part = cur.fetchone()
                if part is None:
                    continue
                total += part["price"]
                conn.execute("INSERT INTO booking_parts (booking_id, part_name, part_price) VALUES (?, ?, ?)",
                             (booking_id, part["name"], part["price"]))
            conn.execute("UPDATE service_bookings SET parts_estimate = ? WHERE id = ?", (total, booking_id))
            conn.commit()
            database.log_event(f"Booking #{booking_id} parts updated by admin: Rs.{total:.2f}")
        finally:
            conn.close()

    # -------------------------------------------- mechanic unavailable handling --
    @classmethod
    def issues_for_user(cls, user_id):
        """Open bookings whose requested mechanic isn't available (customer must decide)."""
        return [b for b in cls.find_by_user(user_id) if b.mechanic_issue and b.status == "Confirmed"]

    @staticmethod
    def _free_mechanic(cur, day, slot, exclude_booking_id=None):
        """An active mechanic with no job in this date+slot (the least busy one), or None."""
        rows = cur.execute(
            "SELECT m.id, m.name, "
            "(SELECT COUNT(*) FROM service_bookings x WHERE x.mechanic_id = m.id "
            " AND x.status IN ('Confirmed', 'In Progress')) AS open_jobs "
            "FROM mechanics m WHERE m.is_active = 1 AND m.id NOT IN ("
            " SELECT mechanic_id FROM service_bookings WHERE mechanic_id IS NOT NULL "
            " AND preferred_date = ? AND time_slot = ? AND status NOT IN ('Cancelled', 'Completed') "
            " AND id != ?) ORDER BY open_jobs, m.name",
            (day, slot, exclude_booking_id or 0),
        ).fetchall()
        return rows[0] if rows else None

    @classmethod
    def reassign_mechanic(cls, booking_id, user_id):
        """Customer's option 1: the garage assigns a different, available mechanic."""
        booking = cls.get(booking_id)
        if booking.user_id != user_id:
            raise BookingNotFoundError(f"Booking #{booking_id} does not exist.")
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            mech = cls._free_mechanic(cur, booking.preferred_date, booking.time_slot, booking_id)
            if mech is None:
                raise MechanicUnavailableError(
                    "No mechanic is free in that time slot right now. Please rearrange the service to another slot."
                )
            conn.execute("UPDATE service_bookings SET mechanic_id = ?, mechanic_requested = 0, "
                         "mechanic_issue = 0 WHERE id = ?", (mech["id"], booking_id))
            conn.commit()
            database.log_event(f"Booking #{booking_id}: customer accepted a different mechanic ({mech['name']})")
            return mech["name"]
        finally:
            conn.close()

    @classmethod
    def reschedule(cls, booking_id, user_id, new_date, new_slot, mechanic_id=None):
        """Customer's option 2: rearrange the service to another date/slot
        (optionally with a specific mechanic who is free then)."""
        booking = cls.get(booking_id)
        if booking.user_id != user_id:
            raise BookingNotFoundError(f"Booking #{booking_id} does not exist.")
        if booking.status != "Confirmed":
            raise ValueError("Only a confirmed booking can be rearranged.")
        if new_slot not in TIME_SLOTS:
            raise SlotPassedError("Please choose a valid time slot.")
        if cls.slot_has_passed(new_date, new_slot):
            raise SlotPassedError("That time slot has already passed. Please choose the current or a later slot.")
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            clash = cur.execute(
                "SELECT service_type FROM service_bookings WHERE vehicle_id = ? AND preferred_date = ? "
                "AND time_slot = ? AND status != 'Cancelled' AND id != ?",
                (booking.vehicle_id, new_date, new_slot, booking_id),
            ).fetchone()
            if clash is not None:
                raise VehicleAlreadyBookedError(
                    f"This car's service is already booked for {new_date} ({new_slot}) - {clash['service_type']}. "
                    "Please choose a different time slot or date."
                )
            taken = cur.execute(
                "SELECT COUNT(*) AS c FROM service_bookings WHERE preferred_date = ? AND time_slot = ? "
                "AND status != 'Cancelled' AND id != ?", (new_date, new_slot, booking_id),
            ).fetchone()["c"]
            if taken >= BAYS_PER_SLOT:
                raise NoBayAvailableError(f"All {BAYS_PER_SLOT} bays are already booked for {new_date} ({new_slot}).")

            new_mech, requested = None, 0
            if mechanic_id:
                mech = cur.execute("SELECT name, is_active FROM mechanics WHERE id = ?", (mechanic_id,)).fetchone()
                if mech is None:
                    raise MechanicNotFoundError("That mechanic does not exist.")
                busy = cur.execute(
                    "SELECT id FROM service_bookings WHERE mechanic_id = ? AND preferred_date = ? AND time_slot = ? "
                    "AND status NOT IN ('Cancelled', 'Completed') AND id != ?",
                    (mechanic_id, new_date, new_slot, booking_id),
                ).fetchone()
                if not mech["is_active"] or busy is not None:
                    raise MechanicUnavailableError(
                        f"{mech['name']} is not available at that time. Choose another mechanic, 'Any mechanic', or another slot."
                    )
                new_mech, requested = mechanic_id, 1

            conn.execute(
                "UPDATE service_bookings SET preferred_date = ?, time_slot = ?, bay_number = ?, mechanic_id = ?, "
                "mechanic_requested = ?, mechanic_issue = 0 WHERE id = ?",
                (new_date, new_slot, taken + 1, new_mech, requested, booking_id),
            )
            conn.commit()
            database.log_event(f"Booking #{booking_id} rearranged to {new_date} {new_slot}")
        finally:
            conn.close()

    @classmethod
    def selected_part_names(cls, booking_id):
        """Names of the parts recorded for a booking (customer's choice until
        staff finalise it)."""
        return [r["part_name"] for r in cls.get_parts_used(booking_id)]

    @classmethod
    def get_parts_used(cls, booking_id):
        """The itemized list of parts recorded against a completed 'Other' booking."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT part_name, part_price FROM booking_parts WHERE booking_id = ? ORDER BY id",
                (booking_id,),
            )
            return cur.fetchall()
        finally:
            conn.close()


class Mechanic:
    """A garage mechanic. Admins manage them from the staff Profile page and
    assign one to each booking; the customer then sees who is working on
    their car."""

    def __init__(self, id, name, phone, specialization, is_active, created_at=None, **extra):
        self.id = id
        self.name = name
        self.phone = phone
        self.specialization = specialization
        self.is_active = bool(is_active)
        self.created_at = created_at
        for key, value in extra.items():
            setattr(self, key, value)

    @staticmethod
    def _from_row(row):
        return Mechanic(**dict(row)) if row is not None else None

    @classmethod
    def all(cls, active_only=False):
        """All mechanics, with how many open (Confirmed / In Progress) jobs
        and how many bookings in total each has."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            query = (
                "SELECT m.*, "
                "(SELECT COUNT(*) FROM service_bookings sb WHERE sb.mechanic_id = m.id "
                " AND sb.status IN ('Confirmed', 'In Progress')) AS open_jobs, "
                "(SELECT COUNT(*) FROM service_bookings sb WHERE sb.mechanic_id = m.id) AS total_jobs "
                "FROM mechanics m "
            )
            if active_only:
                query += "WHERE m.is_active = 1 "
            query += "ORDER BY m.is_active DESC, m.name"
            cur.execute(query)
            return [cls._from_row(r) for r in cur.fetchall()]
        finally:
            conn.close()

    @classmethod
    def get(cls, mechanic_id):
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM mechanics WHERE id = ?", (mechanic_id,))
            mechanic = cls._from_row(cur.fetchone())
            if mechanic is None:
                raise MechanicNotFoundError("That mechanic does not exist.")
            return mechanic
        finally:
            conn.close()

    @classmethod
    def create(cls, name, phone, specialization):
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO mechanics (name, phone, specialization) VALUES (?, ?, ?)",
                (name, phone or None, specialization or None),
            )
            conn.commit()
            database.log_event(f"Mechanic added: {name}")
            return cur.lastrowid
        finally:
            conn.close()

    @classmethod
    def set_active(cls, mechanic_id, active):
        mechanic = cls.get(mechanic_id)
        conn = database.get_connection()
        try:
            conn.execute("UPDATE mechanics SET is_active = ? WHERE id = ?",
                         (int(bool(active)), mechanic_id))
            if not active:
                # Customers who specifically asked for this mechanic must choose what happens next.
                conn.execute(
                    "UPDATE service_bookings SET mechanic_id = NULL, mechanic_issue = 1 "
                    "WHERE mechanic_id = ? AND mechanic_requested = 1 AND status = 'Confirmed'",
                    (mechanic_id,),
                )
            conn.commit()
            database.log_event(
                f"Mechanic '{mechanic.name}' {'activated' if active else 'deactivated'}"
            )
        finally:
            conn.close()

    @classmethod
    def delete(cls, mechanic_id):
        """Remove a mechanic. Refused if they appear on any booking, so a
        customer's booking history never loses its mechanic - deactivate
        them instead."""
        mechanic = cls.get(mechanic_id)
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) AS c FROM service_bookings WHERE mechanic_id = ?",
                        (mechanic_id,))
            if cur.fetchone()["c"] > 0:
                raise MechanicUnavailableError(
                    f"{mechanic.name} is on existing bookings and can't be deleted. "
                    "Deactivate them instead."
                )
            conn.execute("DELETE FROM mechanics WHERE id = ?", (mechanic_id,))
            conn.commit()
            database.log_event(f"Mechanic removed: {mechanic.name}")
        finally:
            conn.close()


class GarageSettings:
    """Garage customer-care phone/email. Shown to every customer; only an
    admin can change them (from the staff Profile page)."""

    @classmethod
    def get_contact(cls):
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT key, value FROM garage_settings")
            data = {r["key"]: r["value"] for r in cur.fetchall()}
            return {
                "phone": data.get("care_phone") or database.DEFAULT_CARE_PHONE,
                "email": data.get("care_email") or database.DEFAULT_CARE_EMAIL,
            }
        finally:
            conn.close()

    @classmethod
    def get_pickup_fee(cls):
        """Doorstep pickup fee. Stored in the database, so it stays whatever
        the admin last set until they change it again."""
        conn = database.get_connection()
        try:
            row = conn.execute("SELECT value FROM garage_settings WHERE key = 'pickup_fee'").fetchone()
            try:
                return float(row["value"]) if row else PICKUP_FEE
            except (TypeError, ValueError):
                return PICKUP_FEE
        finally:
            conn.close()

    @classmethod
    def set_pickup_fee(cls, fee):
        conn = database.get_connection()
        try:
            conn.execute("INSERT OR REPLACE INTO garage_settings (key, value) VALUES ('pickup_fee', ?)", (str(fee),))
            conn.commit()
            database.log_event(f"Doorstep pickup fee updated to Rs.{fee:.2f}")
        finally:
            conn.close()

    @classmethod
    def update_contact(cls, phone, email):
        conn = database.get_connection()
        try:
            conn.execute("INSERT OR REPLACE INTO garage_settings (key, value) VALUES ('care_phone', ?)", (phone,))
            conn.execute("INSERT OR REPLACE INTO garage_settings (key, value) VALUES ('care_email', ?)", (email,))
            conn.commit()
            database.log_event(f"Garage customer-care contact updated: {phone}, {email}")
        finally:
            conn.close()


class ServicePricing:
    """Editable labor price for each service type. Admin-managed."""

    @classmethod
    def all(cls):
        """Return {service_type: price} for every service type."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM service_pricing ORDER BY service_type")
            return {r["service_type"]: r["price"] for r in cur.fetchall()}
        finally:
            conn.close()

    @classmethod
    def update_price(cls, service_type, new_price):
        conn = database.get_connection()
        try:
            conn.execute("UPDATE service_pricing SET price = ? WHERE service_type = ?",
                         (new_price, service_type))
            conn.commit()
            database.log_event(f"Price for '{service_type}' updated to Rs.{new_price:.2f}")
        finally:
            conn.close()


class SparePart:
    """Represents one spare part in the garage's inventory catalog."""

    def __init__(self, id, name, category, price, stock_qty):
        self.id = id
        self.name = name
        self.category = category
        self.price = price
        self.stock_qty = stock_qty

    @property
    def stock_status(self):
        if self.stock_qty <= 0:
            return "Out of Stock"
        if self.stock_qty < 5:
            return "Low Stock"
        return "In Stock"

    @staticmethod
    def _from_row(row):
        if row is None:
            return None
        return SparePart(row["id"], row["name"], row["category"], row["price"], row["stock_qty"])

    @classmethod
    def all(cls):
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM spare_parts ORDER BY category, name")
            return [cls._from_row(r) for r in cur.fetchall()]
        finally:
            conn.close()

    @classmethod
    def low_stock_parts(cls):
        """Parts that are low (<5) or completely out of stock — surfaced as
        an admin-only alert banner, since only staff act on restocking."""
        return [p for p in cls.all() if p.stock_qty < 5]

    @classmethod
    def by_category(cls, category):
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM spare_parts WHERE category = ? ORDER BY name", (category,))
            return [cls._from_row(r) for r in cur.fetchall()]
        finally:
            conn.close()

    @classmethod
    def get(cls, part_id):
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM spare_parts WHERE id = ?", (part_id,))
            part = cls._from_row(cur.fetchone())
            if part is None:
                raise SparePartNotFoundError(f"Spare part #{part_id} not found.")
            return part
        finally:
            conn.close()

    @classmethod
    def create(cls, name, category, price, stock_qty):
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO spare_parts (name, category, price, stock_qty) VALUES (?, ?, ?, ?)",
                (name, category, price, stock_qty),
            )
            conn.commit()
            database.log_event(f"Spare part added to catalog: {name} ({category})")
            return cur.lastrowid
        finally:
            conn.close()

    @classmethod
    def restock(cls, part_id, vendor_name, quantity, unit_cost):
        """Buy more stock of an (often out-of-stock) part from a vendor,
        increasing stock_qty and recording a purchase order."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM spare_parts WHERE id = ?", (part_id,))
            part = cls._from_row(cur.fetchone())
            if part is None:
                raise SparePartNotFoundError(f"Spare part #{part_id} not found.")

            total_cost = round(unit_cost * quantity, 2)
            ordered_at = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            conn.execute("UPDATE spare_parts SET stock_qty = stock_qty + ? WHERE id = ?",
                        (quantity, part_id))
            conn.execute(
                "INSERT INTO purchase_orders (part_id, part_name, vendor_name, quantity, "
                "total_cost, ordered_at) VALUES (?, ?, ?, ?, ?, ?)",
                (part_id, part.name, vendor_name, quantity, total_cost, ordered_at),
            )
            conn.commit()
            database.log_event(
                f"Restocked {quantity}x '{part.name}' from {vendor_name} for Rs.{total_cost:.2f}"
            )
            return total_cost
        finally:
            conn.close()

    @classmethod
    def recent_purchases(cls, limit=None):
        """Full purchase-order history, most recent first. Kept permanently —
        even if the underlying spare part is later deleted from the catalog,
        each row still carries its own snapshotted part_name, so the record
        of what was bought and when is never lost."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            query = "SELECT * FROM purchase_orders ORDER BY ordered_at DESC, id DESC"
            params = ()
            if limit:
                query += " LIMIT ?"
                params = (limit,)
            cur.execute(query, params)
            return cur.fetchall()
        finally:
            conn.close()

    @classmethod
    def delete(cls, part_id):
        """Remove a part from the catalog. Its past purchase orders are kept
        (with part_id cleared to NULL by the ON DELETE SET NULL foreign key,
        but part_name/price/vendor/date all preserved), and any invoices that
        already itemized this part are untouched since those store their own
        independent snapshot."""
        conn = database.get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT name FROM spare_parts WHERE id = ?", (part_id,))
            row = cur.fetchone()
            if row is None:
                raise SparePartNotFoundError(f"Spare part #{part_id} not found.")
            name = row["name"]
            conn.execute("DELETE FROM spare_parts WHERE id = ?", (part_id,))
            conn.commit()
            database.log_event(f"Spare part removed from catalog: {name}")
        finally:
            conn.close()
