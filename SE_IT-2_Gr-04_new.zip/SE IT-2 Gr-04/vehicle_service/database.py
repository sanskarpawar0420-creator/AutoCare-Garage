"""
Low-level database access layer.

Uses Python's built-in sqlite3 module to perform CRUD operations
(Syllabus Module 5 — File Handling, GUI & database programming:
"Database connectivity: to perform CRUD operations (SQLite, MySQL, Oracle,
PostgreSQL etc.)"). SQLite is used here because it ships with Python and
needs no separate server install, which keeps the project easy to run on
any Windows laptop for evaluation.
"""
import datetime
import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "vehicle_service.db")
LOG_PATH = os.path.join(BASE_DIR, "activity.log")

# Default admin/staff account. Kept as constants so init_db() can both seed a
# brand-new database AND upgrade an older database that still has the old
# default credentials, without ever overwriting an admin's own custom login.
OLD_DEFAULT_ADMIN_EMAIL = "admin@servicecenter.com"
DEFAULT_ADMIN_EMAIL = "admin@autocare.com"
DEFAULT_ADMIN_PASSWORD = "AutoCare1234"

DEFAULT_CARE_PHONE = "1800-123-4567"
DEFAULT_CARE_EMAIL = "care@autocare.com"

DEFAULT_SERVICE_PRICES = {
    "General Service": 800.0,
    "Oil Change": 500.0,
    "Other": 600.0,
}

DEFAULT_SPARE_PARTS = [
    # (name, category, price, stock_qty)
    ("Air Filter", "General Service", 350.0, 15),
    ("Cabin Filter", "General Service", 300.0, 10),
    ("Engine Oil Filter", "General Service", 250.0, 20),
    ("Spark Plug Set", "General Service", 600.0, 8),
    ("Engine Oil (5L)", "Oil Change", 1800.0, 25),
    ("Oil Filter", "Oil Change", 250.0, 20),
    ("Drain Plug Gasket", "Oil Change", 50.0, 30),
    ("AC Filter", "Other", 400.0, 10),
    ("Brake Pads (Set)", "Other", 1500.0, 6),
    ("Wiper Blades (Pair)", "Other", 450.0, 12),
    ("Car Battery", "Other", 4500.0, 3),
    ("Headlight Bulb", "Other", 300.0, 0),  # seeded out of stock on purpose
]


def get_connection():
    """Open a new SQLite connection. Rows behave like dictionaries (access by
    column name), and foreign key constraints are enforced."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _add_column_if_missing(cur, table, column, definition):
    """SQLite has no 'ALTER TABLE ... ADD COLUMN IF NOT EXISTS', so we try
    the ALTER TABLE and quietly ignore the error if the column is already
    there. This lets an older vehicle_service.db upgrade itself safely."""
    try:
        cur.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
    except sqlite3.OperationalError as exc:
        if "duplicate column name" not in str(exc).lower():
            raise


def init_db():
    """Create all tables if they don't already exist, upgrade older databases
    in place, and seed default pricing/spare-parts/admin data."""
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name     TEXT NOT NULL,
            email         TEXT NOT NULL UNIQUE,
            phone         TEXT,
            password_hash TEXT NOT NULL,
            is_admin      INTEGER NOT NULL DEFAULT 0,
            created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS vehicles (
            id                   INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id              INTEGER NOT NULL,
            vehicle_type         TEXT NOT NULL,
            brand                TEXT NOT NULL,
            model                TEXT NOT NULL,
            registration_number  TEXT NOT NULL,
            year                 INTEGER,
            created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS mechanics (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            name           TEXT NOT NULL,
            phone          TEXT,
            specialization TEXT,
            is_active      INTEGER NOT NULL DEFAULT 1,
            created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS service_bookings (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id         INTEGER NOT NULL,
            vehicle_id      INTEGER NOT NULL,
            service_type    TEXT NOT NULL,
            preferred_date  TEXT NOT NULL,
            time_slot       TEXT NOT NULL,
            bay_number      INTEGER NOT NULL,
            status          TEXT NOT NULL DEFAULT 'Confirmed',
            notes           TEXT,
            created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
        )
    """)
    # Pricing/pickup columns added after the original release — applied to
    # both fresh and pre-existing databases.
    _add_column_if_missing(cur, "service_bookings", "service_price", "REAL DEFAULT 0")
    _add_column_if_missing(cur, "service_bookings", "parts_estimate", "REAL DEFAULT 0")
    _add_column_if_missing(cur, "service_bookings", "pickup_required", "INTEGER DEFAULT 0")
    _add_column_if_missing(cur, "service_bookings", "pickup_address", "TEXT")
    _add_column_if_missing(cur, "service_bookings", "pickup_fee", "REAL DEFAULT 0")
    # After service: customer chooses home delivery or self-collection.
    # delivery_option: NULL | 'Home Delivery' | 'Self Pickup'
    # delivery_status: NULL | 'Pending' | 'Delivered' | 'Collected' | 'Missed'
    _add_column_if_missing(cur, "service_bookings", "delivery_option", "TEXT")
    _add_column_if_missing(cur, "service_bookings", "delivery_address", "TEXT")
    _add_column_if_missing(cur, "service_bookings", "collect_date", "TEXT")
    _add_column_if_missing(cur, "service_bookings", "collect_slot", "TEXT")
    _add_column_if_missing(cur, "service_bookings", "delivery_status", "TEXT")
    _add_column_if_missing(cur, "service_bookings", "missed_count", "INTEGER DEFAULT 0")
    # When a Pending delivery/collection completes automatically (see models.AUTO_HANDOVER_MINUTES).
    _add_column_if_missing(cur, "service_bookings", "handover_due", "TEXT")
    # 1 when the customer picked a specific mechanic while booking (0 = any mechanic).
    _add_column_if_missing(cur, "service_bookings", "mechanic_requested", "INTEGER DEFAULT 0")
    # 1 while the customer still has to decide what to do because the mechanic
    # they asked for isn't available (assign another one / rearrange the service).
    _add_column_if_missing(cur, "service_bookings", "mechanic_issue", "INTEGER DEFAULT 0")
    # Mechanic assigned by an admin (NULL until assigned).
    _add_column_if_missing(cur, "service_bookings", "mechanic_id",
                           "INTEGER REFERENCES mechanics(id) ON DELETE SET NULL")

    cur.execute("""
        CREATE TABLE IF NOT EXISTS service_pricing (
            service_type TEXT PRIMARY KEY,
            price        REAL NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS spare_parts (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT NOT NULL,
            category   TEXT NOT NULL,
            price      REAL NOT NULL,
            stock_qty  INTEGER NOT NULL DEFAULT 0
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS purchase_orders (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            part_id      INTEGER,
            part_name    TEXT,
            vendor_name  TEXT NOT NULL,
            quantity     INTEGER NOT NULL,
            total_cost   REAL NOT NULL,
            ordered_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (part_id) REFERENCES spare_parts(id) ON DELETE SET NULL
        )
    """)
    _add_column_if_missing(cur, "purchase_orders", "part_name", "TEXT")
    conn.commit()

    # Backfill part_name on any older purchase-order rows that predate this
    # column, so their history keeps displaying correctly.
    cur.execute("""
        UPDATE purchase_orders
        SET part_name = (SELECT name FROM spare_parts WHERE spare_parts.id = purchase_orders.part_id)
        WHERE part_name IS NULL AND part_id IS NOT NULL
    """)
    conn.commit()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS booking_parts (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id  INTEGER NOT NULL,
            part_name   TEXT NOT NULL,
            part_price  REAL NOT NULL,
            FOREIGN KEY (booking_id) REFERENCES service_bookings(id) ON DELETE CASCADE
        )
    """)

    conn.commit()

    # Garage-wide settings (customer-care phone/email) edited by the admin.
    cur.execute("""
        CREATE TABLE IF NOT EXISTS garage_settings (
            key   TEXT PRIMARY KEY,
            value TEXT
        )
    """)
    for key, value in (("care_phone", DEFAULT_CARE_PHONE), ("care_email", DEFAULT_CARE_EMAIL)):
        cur.execute("INSERT OR IGNORE INTO garage_settings (key, value) VALUES (?, ?)", (key, value))
    conn.commit()

    # ---- seed default service pricing (only rows that don't already exist) --
    for service_type, price in DEFAULT_SERVICE_PRICES.items():
        cur.execute("SELECT 1 FROM service_pricing WHERE service_type = ?", (service_type,))
        if cur.fetchone() is None:
            cur.execute("INSERT INTO service_pricing (service_type, price) VALUES (?, ?)",
                        (service_type, price))
    conn.commit()

    # ---- seed default spare parts catalog (only if the table is empty) ------
    cur.execute("SELECT COUNT(*) AS c FROM spare_parts")
    if cur.fetchone()["c"] == 0:
        cur.executemany(
            "INSERT INTO spare_parts (name, category, price, stock_qty) VALUES (?, ?, ?, ?)",
            DEFAULT_SPARE_PARTS,
        )
        conn.commit()
    else:
        # Backfill any newly-introduced catalog parts (e.g. AC Filter) onto a
        # database that was already seeded by an earlier version of the app.
        for name, category, price, stock_qty in DEFAULT_SPARE_PARTS:
            cur.execute("SELECT 1 FROM spare_parts WHERE name = ?", (name,))
            if cur.fetchone() is None:
                cur.execute(
                    "INSERT INTO spare_parts (name, category, price, stock_qty) VALUES (?, ?, ?, ?)",
                    (name, category, price, stock_qty),
                )
        conn.commit()

    # ---- admin account: migrate old default, or seed fresh -------------------
    from werkzeug.security import generate_password_hash

    cur.execute("SELECT id FROM users WHERE email = ?", (OLD_DEFAULT_ADMIN_EMAIL,))
    old_admin = cur.fetchone()
    if old_admin is not None:
        cur.execute("SELECT id FROM users WHERE email = ?", (DEFAULT_ADMIN_EMAIL,))
        if cur.fetchone() is None:
            # Still using the old seeded demo account — safe to roll it
            # forward to the new default credentials automatically.
            cur.execute(
                "UPDATE users SET email = ?, password_hash = ? WHERE id = ?",
                (DEFAULT_ADMIN_EMAIL, generate_password_hash(DEFAULT_ADMIN_PASSWORD), old_admin["id"]),
            )
            conn.commit()

    cur.execute("SELECT id FROM users WHERE is_admin = 1")
    if cur.fetchone() is None:
        # No admin account exists at all yet (brand-new database) — seed one.
        cur.execute(
            "INSERT INTO users (full_name, email, phone, password_hash, is_admin) "
            "VALUES (?, ?, ?, ?, ?)",
            ("Service Center Admin", DEFAULT_ADMIN_EMAIL, "9999999999",
             generate_password_hash(DEFAULT_ADMIN_PASSWORD), 1),
        )
        conn.commit()

    conn.close()


def log_event(message):
    """Append a timestamped line to activity.log.

    Demonstrates File Handling (Syllabus Module 5.1 — file operations:
    read, write, rename, delete) by keeping a plain-text audit trail of
    every important action (registrations, logins, bookings, cancellations,
    price changes, restocks).
    """
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"[{timestamp}] {message}\n")
    except OSError:
        # Logging must never crash the request that triggered it.
        pass
