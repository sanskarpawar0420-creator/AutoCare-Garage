"""
vehicle_service
================
Core application package for the Online Vehicle Servicing Management System.

Splitting the project into this package (with database.py, models.py,
exceptions.py, notifications.py and analytics.py as sub-modules) is a direct
application of Syllabus Module 4.1 — "Packages: creating user defined
packages and importing packages".
"""

__version__ = "1.0.0"
