"""
Custom exception classes for the Vehicle Servicing Management System.

Demonstrates User-Defined Exceptions (Syllabus Module 4 — Exception Handling:
compile time errors, runtime errors, exceptions, types of exception, try
statement, except block, User-Defined Exceptions).
"""


class VehicleServiceError(Exception):
    """Base class for every application-specific error. Catch this to handle
    any known failure from the vehicle_service package in one except block."""
    pass


class UserAlreadyExistsError(VehicleServiceError):
    """Raised when someone registers with an email that is already in use."""
    pass


class InvalidCredentialsError(VehicleServiceError):
    """Raised when a login email/password combination does not match any account."""
    pass


class VehicleNotFoundError(VehicleServiceError):
    """Raised when a requested vehicle does not exist or does not belong to the user."""
    pass


class NoBayAvailableError(VehicleServiceError):
    """Raised when every service bay is already booked for the chosen date and time slot."""
    pass


class BookingNotFoundError(VehicleServiceError):
    """Raised when a requested booking does not exist or does not belong to the user."""
    pass


class SparePartNotFoundError(VehicleServiceError):
    """Raised when a requested spare part does not exist in the catalog."""
    pass


class MechanicNotFoundError(VehicleServiceError):
    """Raised when a requested mechanic does not exist."""
    pass


class PartNotFoundError(VehicleServiceError):
    """Raised when a requested spare part does not exist in inventory."""
    pass


class InsufficientStockError(VehicleServiceError):
    """Raised when a booking requests more units of a part than are in stock."""
    pass


class MechanicNotAssignedError(VehicleServiceError):
    """Raised when a booking is moved to In Progress/Completed without a mechanic."""
    pass


class MechanicUnavailableError(VehicleServiceError):
    """Raised when a mechanic is inactive or already booked for that date and slot."""
    pass


class SlotPassedError(VehicleServiceError):
    """Raised when the chosen date/time slot has already ended."""
    pass


class VehicleAlreadyBookedError(VehicleServiceError):
    """Raised when the same vehicle already has a service booked for the chosen date and time slot."""
    pass
