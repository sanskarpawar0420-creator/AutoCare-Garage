"""
Simulated notification service.

Demonstrates multithreading (Syllabus Module 4.1 — "Multi-threading: Thread
and Process, starting a thread, threading module, Synchronizing threads").
Sending a booking confirmation is simulated as a slow operation (as a real
email/SMS gateway call would be). It runs on a background thread so the
customer's browser gets an instant response instead of waiting for it.
"""
import threading
import time

from . import database


def _send_confirmation(email, booking_id, preferred_date, time_slot, bay_number):
    """The actual work performed on the background thread."""
    time.sleep(2)  # simulate email/SMS gateway network latency
    message = (
        f"[Notification Thread] Booking #{booking_id} CONFIRMED for {email} -> "
        f"{preferred_date}, {time_slot}, Bay {bay_number}"
    )
    print(message)  # visible in the terminal running the Flask server
    database.log_event(message)


def send_booking_confirmation(email, booking_id, preferred_date, time_slot, bay_number):
    """Fire-and-forget: start a daemon thread and return immediately."""
    thread = threading.Thread(
        target=_send_confirmation,
        args=(email, booking_id, preferred_date, time_slot, bay_number),
        daemon=True,
    )
    thread.start()
